#include	"libft.h"

void		ft_strrealloccp(char **dst, char *src, size_t len_tot, size_t len_cp)
{
	ft_realloc((void**)dst, ft_strlen(*dst), len_tot);
	ft_strncat(*dst, src, len_cp);
}
